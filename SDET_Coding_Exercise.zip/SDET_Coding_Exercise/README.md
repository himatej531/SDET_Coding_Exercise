<!-- GETTING STARTED -->
## Getting Started

This is an example of how you may give instructions on setting up your project locally.
To get a local copy up and running follow these simple example steps.

### Prerequisites
IntelliJ IDE
MAVEN
JAVA
RestAssured
TestNG
ORG JSON

### Installation

_Below is an example of how you can setup your app.

1. Install JAVA and setup Environmental variables
2. Download Maven ZIP and setup Environmental variables
3. Clone the repo
   ```sh
   git clone https://github.com/your_username_/Project-Name.git
   ```
4. Install mvn  packages
   ```sh
   mvn install
   ```
5. Run tests:
Open Maven profile and select 'test' under Lifecycle or run 'mvn test' on cmd