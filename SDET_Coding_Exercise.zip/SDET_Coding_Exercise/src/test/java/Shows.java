import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

import static io.restassured.RestAssured.given;

public class Shows {

    JSONArray ex1Result;
    RequestSpecification specification;

    @BeforeTest
    public void apiSetup() {
        //API Request
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.setBaseUri("https://api.tvmaze.com");
        builder.setContentType("application/json");
        specification = builder.build();
    }

    @Test
    public void getShows() {


        Response response = given().spec(specification).get("/shows");
        List<String> showNames = new ArrayList<>();

        //JSON Parsing
        JSONArray jsonArray = new JSONArray(response.body().asString());
        ex1Result = new JSONArray();
        for (int n = 0; n < jsonArray.length(); n++) {
            JSONObject jsonObject = jsonArray.getJSONObject(n);
            if (!(jsonObject.isNull("network"))) {

                JSONObject network = jsonObject.getJSONObject("network");

                if (network.get("name").equals("HBO")) {
                    if (!(jsonObject.getJSONArray("genres").isEmpty())) {
                        JSONArray gArray = jsonObject.getJSONArray("genres");
                        for (int j = 0; j < gArray.length(); j++) {
                            if (gArray.get(j).equals("Drama")) {
                                if (!(jsonObject.isNull("premiered"))) {
                                    {
                                        int startYear = Integer.parseInt(jsonObject.getString("premiered").substring(0, 4));
                                        if (2012 < startYear && startYear < 2016 ) {
                                            ex1Result.put(jsonObject);

                                            showNames.add(jsonObject.getString("name"));
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Assert.assertEquals(showNames.size(), 3, "ActualShows count should match ExpectedShows count");
        Assert.assertTrue(showNames.contains("Looking"), "Looking doesn't match the expected list");
        Assert.assertTrue(showNames.contains("The Leftovers"), "The Leftovers doesn't match the expected list");
        Assert.assertTrue(showNames.contains("True Detective"), "True Detective doesn't match the expected list");
        System.out.println("Exercise-1: Getting a list of shows: ");
        System.out.println(showNames.get(0)+", "+showNames.get(1)+", "+showNames.get(2));

    }


    @Test(dependsOnMethods = "getShows")
    public void getEpisodes() {

        List<List<Integer>> ex2ResultDuration = new ArrayList<>();
        List<List<Integer>> ex2ResultEpisodes = new ArrayList<>();

        for (int i = 0; i < ex1Result.length(); i++) {
            List<Integer> countDuration = new ArrayList<>();
            List<Integer> countEpisodes = new ArrayList<>();
            JSONObject jsonObject = ex1Result.getJSONObject(i);
            String url = "/shows/" + jsonObject.get("id") + "/episodes";
            Response response2 = given().spec(specification).get(url);
            JSONArray jsonArray2 = new JSONArray(response2.body().asString());
            int prev = -1;
            for (int j = 0; j < jsonArray2.length(); j++) {
                JSONObject obj = jsonArray2.getJSONObject(j);
                if (!obj.isNull("season")) {
                    int season = obj.getInt("season");
                    if (prev != season) {
                        prev = season;
                        countDuration.add(0);
                        countEpisodes.add(0);
                    }
                    countEpisodes.set(season - 1, countEpisodes.get(season - 1) + 1);
                    countDuration.set(season - 1, countDuration.get(season - 1) + obj.getInt("runtime"));
                }
            }
            ex2ResultDuration.add(countDuration);
            ex2ResultEpisodes.add(countEpisodes);
        }


        for (int j = 0; j < ex2ResultDuration.size(); j++) {
            System.out.println();
            System.out.println("Exercise-2 Episodes: " + ex1Result.getJSONObject(j).getString("name"));
            int season = 1;
            for (int i = 0; i < ex2ResultDuration.get(j).size(); i++) {
                System.out.println("Season " + season + " has " + ex2ResultEpisodes.get(j).get(i) + " episodes, the entire season has a total runtime of " + ex2ResultDuration.get(j).get(i) + " minutes.");
                season++;
            }

        }

    }
}